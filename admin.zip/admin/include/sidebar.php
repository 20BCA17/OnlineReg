<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="#"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="patient.php"><i class="fa fa-desktop"></i>Patient</a>
                    </li>
					<li>
                        <a href="adddoctor.php"><i class="fa fa-bar-chart-o"></i> Administrator</a>
                    </li>
                    <!-- <li>
                        <a href="lab.php"><i class="fa fa-qrcode"></i>LabWork</a>
                    </li> -->
                    <li>
                        <a href="lab_detail.php"><i class="fa fa-sitemap"></i>LabWork<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="Addlab.php">Add Lab</a>
                            </li>
                            <li>
                                <a href="Add_lab_item.php">Lab Item</a>
                            </li>
                            <li>
                                <a href="lab_detail.php">Lab Work</a>
                            </li>
                           
                           </li>
                </ul>
                    <!-- <li>
                        <a href="lab_detail.php"><i class="fa fa-table"></i> Lab</a>
                    </li> -->
                    <li>
                        <a href="logout.php"><i class="fa fa-edit"></i> Logout </a>
                    </li>
                </ul>

            </div>

        </nav>