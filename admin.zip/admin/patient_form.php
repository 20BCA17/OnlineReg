<?php
include "auth.php";
include "include/header.php";
?>
 <html>
        <head>
        <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>   -->

<script>
    <?php
$date = date("Y-m-d");
?>
</script>
        </head>
        <body>
<div id="page-wrapper">
        <div id="page-inner">

            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                            Dashboard <small>Summary of your App</small>
                    </h1>
					<ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Library</a></li>
                        <li class="active">Data</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Laboratory Management
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12">
                                    <form id="patientData" method="POST" role="form" action="patient_insert.php">
                                    <div class="row">
                                                <div class="col-md-12">
                                                    <h1 class="page-header ">
                                                        Personal Details
                                                </div>
                                            </div>

                                            <div class="col-lg-3">
                                                <input type="text" name="Today_Date" value=" <?php
                                                    $currentDateTime = date('d-F-Y');
                                                    echo $currentDateTime;
                                                    ?>" class="form-control" readonly>
                                                </div>
                                            <div class="form-group col-md-3">
                                                <select name="Doctor_Name" id="" class="form-control">
                                                    <option value="">Dr Nitin</option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                </select>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group input-group ">
                                                    <input type="text" class="form-control"
                                                        placeholder="OPD No :" name="Patient_Code" value="">
                                                    <span class="input-group-btn">
                                                        <button class="btn btn-primary" type="submit"><i
                                                        class="fa fa-pen"></i>
                                                        </button>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="ph">

                                                 <script type="text/javascript">
                                                function preview(event) {
                                                    var reader = new FileReader();
                                                    reader.onload = function(){
                                                    var output = document.getElementById('output_image');
                                                    output.src = reader.result;
                                                    }
                                                    reader.readAsDataURL(event.target.files[0]);
                                                }
                                                </script>
                                                <img id="output_image" height=155px width=125px\>
                                    <input name="UploadDocument" type="file" id="choose" name="file"
                                        accept=".jpg,.jpeg,.png" style="display: none;" onchange="preview(event)"accept="image/*" / ><br><br>

                                       <center>
                                     <label for="choose" class="custom-file-upload" id="choose-label" >Select  Photo</label>
                                         </center>
                                      </div>
                                      <div class="form-group col-md-2">
                                                <select name="Mr" id="" class="form-control">
                                                    <option value="Mr">Mr</option>
                                                    <option value="Mrs">Mrs</option>
                                                    <option value="Ms">Ms</option>
                                                    <option value="Miss">Miss</option>
                                                </select>
                                            </div>

                                            <div class="form-group col-md-3">
                                                <input type="text" name="fname" id="first_name" placeholder="First Name"
                                                    class="form-control" required data-parsley-pattern="^[a-zA-Z]+$" data-parsley-trigger >
                                            </div>
                                            <div class="form-group col-md-3">
                                                <input type="text" name="lname" id="" placeholder="Last Name"
                                                    class="form-control" name="Name" required data-parsley-pattern="^[a-zA-Z]+$" >
                                            </div>

                                            <div class="form-group col-md-3">
                                                <input type="text" placeholder="Date Of Birth"
                                                onfocus="(this.type='date')"  class="form-control" name="dob" max=<?php echo "$date" ?>required>
                                            </div>

                                            <div class="form-group col-md-1 ">
                                                <input type="text" name="dob_year" id="" value="<?php echo date('Y'); ?>" class="form-control" readonly >
                                            </div>
                                            <div class="form-group col-md-1 ">
                                                <input type="button" name="dob_month" id="" value="<?php echo date('F'); ?>" class="form-control" readonly>
                                            </div>
                                            <div class="form-group col-md-2">
                                                <select name="gender" id="" class="form-control" name="Gender" required >
                                                    <option>Gender</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                    <option value="Other">Other</option>

                                                </select>
                                            </div>

                                            <div class="form-group col-md-4">
                                                <input type="text" placeholder="mobile" class="form-control" name="Phone" data-minlength="10" maxlength="10" id="mobile" data-parsley-minlength="10" data-parsley-minlength-message="minlength 10 number" data-parsley-type="digits" data-parsley-type-message="only numbers" class="input_text" value="" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="email" placeholder="Email" class="form-control" name="mail" required data-parsley-type="email">
                                            </div>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <h1 class="page-header ">
                                                        Contact Details
                                                </div>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" placeholder="Flat/Door/Block No"
                                                    class="form-control" name="flat" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" placeholder="Road/ Street/Lane" class="form-control" name="road" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" placeholder="Place" class="form-control" name="place" required>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <select name="country" id="" class="form-control" readonly >

                                                    <option value="">India</option>
                                                    <option value="">Us</option>
                                                    <option value="">Pk</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <select name="state" id="" class="form-control" readonly >

                                                    <option value="">Gujarat</option>
                                                    <option value="">Maharastra</option>
                                                    <option value="">Uttar Pradesh</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <input type="text" name="pin" id="" placeholder="Pin/Zip Code"
                                                    class="form-control" required>
                                            </div> <br><br><br><br><br><br>
                                            <div >
                                              <input type="submit" name="submit" value="submit" class="btn btn-primary" id="submit">


                                                
                                                <input type="submit" name="save_sub" value="Save & Add More Patient" class="btn btn-primary">
                                                <button class="btn btn-primary" type="reset">Reset</button>
                                            </div>

                                    </form>
                                    </div>
                                </div>



</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script>
$("#patientData").parsley();
// $(document).ready(function(){
//     $('#validate_form').parsley();

//  $('#validate_form').on('submit', function(event){
//   event.preventDefault();
//   if($('#validate_form').parsley().isValid())
//   {
//    $.ajax({
//     url:"patient_insert.php",
//     method:"POST",
//     data:$(this).serialize(),
//     beforeSend:function(){

//      $('#submit').attr('disabled','disabled');
//      $('#submit').val('Submitting...');
//     },
//     success:function(data)
//     {
//      $('#validate_form')[0].reset();
//      $('#validate_form').parsley().reset();
//      $('#submit').attr('disabled',false);
//      $('#submit').val('Submit');
//      alert(data);
//     }
//    });
//   }
//  });
// });
</script>
<?php
include "include/footer.php";
include "include/script.php";
?>


