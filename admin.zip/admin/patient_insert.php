
<?php
include_once 'db.php';

if (isset($_POST['submit'])) {
    $Today_Date = $_POST['Today_Date'];
    $Doctor_Name = $_POST['Doctor_Name'];
    $Patient_Code = $_POST['Patient_Code'];
    // $UploadDocument = $_POST['UploadDocument'];
    $Mr = $_POST['Mr'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $dob = $_POST['dob'];
    $dob_year = $_POST['dob_year'];
    $gender = $_POST['gender'];
    $Phone = $_POST['Phone'];
    $mail = $_POST['mail'];
    $flat = $_POST['flat'];
    $road = $_POST['road'];
    $place = $_POST['place'];
    $state = $_POST['state'];
    $country = $_POST['country'];
    $pin = $_POST['pin'];

    
	$name = $_FILES['UploadDocument']['name'];
	list($txt, $ext) = explode(".", $name);
	$image_name = time().".".$ext;
	$tmp = $_FILES['UploadDocument']['tmp_name'];

	move_uploaded_file($tmp, 'upload/'.$image_name);


    $sql = "INSERT INTO idx_insert (Today_Date,Doctor_Name,Patient_Code,UploadDocument,Mr,fname,lname,dob,dob_year,gender,Phone,mail,flat,road,place,state,country,pin)
	 VALUES ('$Today_Date','$Doctor_Name','$Patient_Code','$image_name','$Mr','$fname','$lname','$dob','$dob_year','$gender','$Phone','$mail','$flat','$road','$place','$state','$country','$pin')";
    if (mysqli_query($con, $sql)) {

        echo "<script>alert('New record created successfully !')
        window.location.href = 'patient.php';
      </script>";
    
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>
<?php
include_once 'db.php';

if (isset($_POST['save_sub'])) {
    $Today_Date = $_POST['Today_Date'];
    $Doctor_Name = $_POST['Doctor_Name'];
    $Patient_Code = $_POST['Patient_Code'];
    // $UploadDocument = $_POST['UploadDocument'];
    $Mr = $_POST['Mr'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $dob = $_POST['dob'];
    $dob_year = $_POST['dob_year'];
    $gender = $_POST['gender'];
    $Phone = $_POST['Phone'];
    $mail = $_POST['mail'];
    $flat = $_POST['flat'];
    $road = $_POST['road'];
    $place = $_POST['place'];
    $state = $_POST['state'];
    $country = $_POST['country'];
    $pin = $_POST['pin'];

    
	$name = $_FILES['UploadDocument']['name'];
	list($txt, $ext) = explode(".", $name);
	$image_name = time().".".$ext;
	$tmp = $_FILES['UploadDocument']['tmp_name'];

	move_uploaded_file($tmp, 'upload/'.$image_name);


    $sql = "INSERT INTO idx_insert (Today_Date,Doctor_Name,Patient_Code,UploadDocument,Mr,fname,lname,dob,dob_year,gender,Phone,mail,flat,road,place,state,country,pin)
	 VALUES ('$Today_Date','$Doctor_Name','$Patient_Code','$image_name','$Mr','$fname','$lname','$dob','$dob_year','$gender','$Phone','$mail','$flat','$road','$place','$state','$country','$pin')";
    if (mysqli_query($con, $sql)) {

        echo "<script>alert('New record created successfully !')
        window.location.href = 'patient_form.php';
      </script>";
    
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>
<?php
include_once 'db.php';

if (isset($_POST['update'])) {
    $id=$_POST['id'];
    $Today_Date = $_POST['Today_Date'];
    $Doctor_Name = $_POST['Doctor_Name'];
    $Patient_Code = $_POST['Patient_Code'];
    // $UploadDocument = $_POST['UploadDocument'];
    $Mr = $_POST['Mr'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $dob = $_POST['dob'];
    $dob_year = $_POST['dob_year'];
    $gender = $_POST['gender'];
    $Phone = $_POST['Phone'];
    $mail = $_POST['mail'];
    $flat = $_POST['flat'];
    $road = $_POST['road'];
    $place = $_POST['place'];
    $state = $_POST['state'];
    $country = $_POST['country'];
    $pin = $_POST['pin'];

    
	$name = $_FILES['UploadDocument']['name'];
	list($txt, $ext) = explode(".", $name);
	$image_name = time().".".$ext;
	$tmp = $_FILES['UploadDocument']['tmp_name'];

	move_uploaded_file($tmp, 'upload/'.$image_name);


    $update ="UPDATE idx_insert set fname='$fname',lname='$lname',Today_Date='$Today_Date',Doctor_Name='$Doctor_Name',Patient_Code='$Patient_Code',Mr='$Mr',dob='$dob',dob_year='$dob_year',gender='$gender',Phone='$Phone',mail='$mail',flat='$flat',road='$road',place='$place',state='$state',country='$country',pin='$pin' WHERE id='$id'";
    if (mysqli_query($con,$update)) {

        echo "<script>alert('updated successfully !')
        window.location.href = 'patient.php';
      </script>";
    
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>








<!-- Delete -->


<?php
include_once 'db.php';
$delete = "DELETE FROM idx_insert WHERE id='" . $_GET["id"] . "'";
if (mysqli_query($con, $delete)) {
    header("location:patient.php");
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($con);
?>

<?php
include_once 'db.php';
if (isset($_POST['add'])) {

    header("location:patient_form.php");

}

?>
