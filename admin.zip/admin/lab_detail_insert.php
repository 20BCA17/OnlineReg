<?php
include_once 'db.php';

if (isset($_POST['submit'])) {
    $Start_Date = $_POST['Start_Date'];
    $Select_Lab = $_POST['Select_Lab'];
    $Doctor_Name = $_POST['Doctor_Name'];
    $End_Date = $_POST['End_Date'];
    $exampleRadios = $_POST['exampleRadios'];
    $Theeth_No = $_POST['Theeth_No'];
    $Sent = $_POST['Sent'];
    $Select_Stage = $_POST['Select_Stage'];
    $Primary_Teeth = $_POST['Primary_Teeth'];
    $Select_All_Teeth = $_POST['Select_All_Teeth'];
    $Select_Components_items = $_POST['Select_Components_items'];
    $Select_Tooth = $_POST['Select_Tooth'];
    $Price = $_POST['Price'];
    $Total_Cost = $_POST['Total_Cost'];
    $Order_Placed = $_POST['Order_Placed'];
    $Instruction = $_POST['Instruction'];
 
 
   
    $sql = "INSERT INTO lab_detail_insert(Start_Date,Select_Lab,Doctor_Name,End_Date,exampleRadios,Theeth_No,Sent,Select_Stage,Primary_Teeth,Select_All_Teeth,Select_Components_items,Select_Tooth,Price,Total_Cost,Order_Placed,Instruction)
	 VALUES ('$Start_Date','$Select_Lab','$Doctor_Name','$End_Date','$exampleRadios','$Theeth_No','$Sent','$Select_Stage','$Primary_Teeth','$Select_All_Teeth','$Select_Components_items','$Select_Tooth','$Price','$Total_Cost','$Order_Placed','$Instruction')";
    if (mysqli_query($con, $sql)) {

        echo "<script>alert('New record created successfully !')
        window.location.href = 'Add_lab_item.php';
      </script>";
    
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }   
    mysqli_close($con);
}

?>

<?php

if (isset($_POST['Add'])) {

    header("location:lab_detail_form.php");

}

?>
