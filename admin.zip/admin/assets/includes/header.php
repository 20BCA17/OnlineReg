<nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">

                <a class="navbar-brand" href="#">Manege Patient</a>
            </div>

            <ul class="nav navbar-top-links navbar-right">
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>

                <!-- /.dropdown -->

                <!-- /.dropdown -->

                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>