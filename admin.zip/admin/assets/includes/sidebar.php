<nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="idx.php"><i class="fa fa-users"></i> Patient</a>
                    </li>
                    <li>
                        <a href="adddoctor.php"><i class="fa fa-user"></i> Administrator</a>
                    </li>
                    <li>
                        <a href="Addlab.php"><i class="fa fa-flask"></i> LabWork</a>
                    </li>

                    <li>
                        <a href="lab.php"><i class="fa fa-sign-out"></i> Lab</a>
                    </li>
                    <li>
                        <a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
                    </li>
                </ul>
            </div>

        </nav>
