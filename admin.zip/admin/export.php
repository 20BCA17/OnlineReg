<?php require "db.php";?>
                                           <?php
                                                $data = mysqli_query($con, "SELECT * FROM idx_insert");
                                            ?>
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr class="dark">
                                                        <th>Image</th>
                                                        <th>Name</th>
                                                        <th>Patient_Code</th>
                                                        <!-- <th>Age</th> -->
                                                        <th>Gender</th>
                                                        <th>Contact</th>
                                                        <th>Action</th>
                                                        
                                                    </tr>
                                                </thead>
                                               <?php foreach ($data as $value) {?>
                                                <tr>
                                                <td><img width="100px" src="upload/<?php echo $value['UploadDocument']; ?>"></td>
                                                    <td><?php echo $value['fname']; ?></td>
                                                    <td><?php echo $value ['Patient_Code']; ?></td>
                                                    <!-- <td><?php //echo $value['fname']; ?></td> -->
                                                    <td><?php echo $value['gender']; ?></td>
                                                    <td><?php echo $value['Phone']; ?></td>
                                                
                                                </tr>
                                                <?php }?>
                                          </table>

        <?php
header('Content-Type:application/xls');
header('Content-Disposition:atttachment;filename=report.xls');
        ?>