
<?php include "db.php"; ?>

<?php  session_start();
 if(isset($_SESSION['email'])){
    header("Location: patient.php");
 }
?>

<!DOCTYPE html>
<html>

<head>
    <title>Registration Page</title>
    <link rel="stylesheet" type="text/css" href="css//bootstrap.css">
    <!-- CSS only -->

</head>

<body><br> <br> <br>
    <div class="container">
        <div class="row col-md-6 col-md-offset-3">
            <div class="panel panel-primary">
                <div class="panel-heading text-center">
                    <h1>Login Page</h1>
                </div>
                <div class="panel-body">
                    <form action="login_check.php" method="POST">
                        
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" id="email" name="email" placeholder="Email Address/Mobile Number" required data-parsley-type="email">
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password"  placeholder="Password"/>
                        </div>
                       <div class="form-group ">
                            <input type="checkbox"> Remember me for 15 days. &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            <a href=""> Forgot Password ?</a>
                       </div >
                       <div class="form-group " >
                        <button class="btn btn-primary" type="submit" name="submit"> Login Now</button>   
                        
                       </div>
                       
                        Don't have an account ?<a href="registration.php">Sign Up</a>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
    <div class="toast" role="alert" aria-live="assertive" aria-atomic="true">
      
     
    </div>
</body>

</html>