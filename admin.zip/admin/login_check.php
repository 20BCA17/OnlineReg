
<?php
session_start();
include('db.php');


if(isset($_POST["submit"])) {

 //Username and Password sent from Form
 $email = mysqli_real_escape_string($con, $_POST['email']);
 $password = mysqli_real_escape_string($con, $_POST['password']);
 $password = md5($password);
 $sql = "SELECT id FROM registration WHERE email='$email' AND '$password'";
 $query = mysqli_query($con, $sql);
 $res=mysqli_num_rows($query);
 
 if($res == 1){
    $_SESSION['email'] = $email;
    header("Location: patient.php");
 }else{
    header("Location: login.php");
 }
}

?>

