<?php 
include "auth.php";
include "include/header.php";
?>

      
<div id="page-wrapper">
        <div id="page-inner">

            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                            Dashboard <small>Summary of your App</small>
                    </h1>
					<ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Library</a></li>
                        <li class="active">Data</li>
                    </ol>
                </div>
            </div>
            <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Basic Details
                        </h1>
                    </div>
                </div>
                <!-- form input doctor details-->
                <div class="form-row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <sdiv class="panel-heading">
                                Laboratory Management
                            </div>

                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12">
                                        <form action="Add_lab_item_insert.php" method="POST" role="form" enctype="multipart/form-data" id="patientData">
                                        <div class="row">
                                                <div class="col-md-12">
                                                    <h2 class="page-header ">
                                                        Labitem
                                                    </h2>
                                                </div>
                                            </div>
                                            <div class="form-group col-md-6">
                                                <select name="Component_Category"  class="form-control">
                                                    <option value="Select Component Category">Select Component Category</option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                </select>
                                            </div>

                                            <div class="form-group col-md-6">

                                                <input type="text" class="form-control" placeholder="Component Name" name="Component_Name" required>
                                            </div>
                                            
                                            <div class="form-group  col-md-6">

                                                <input type="text" class="form-control"
                                                    placeholder=" Component Discription" name="Component_Discription" required>
                                            </div>

                                            <div class="form-group  col-md-6">

                                                <input type="text" class="form-control" placeholder=" ₹ 0" name="Cost" required>
                                            </div>
                                          
                                            <div class="btn">
                                            <input type="submit" name="ni" value="Save" class="btn btn-success">
                                             
                                                <button class="btn btn-primary"><a href="Add_lab_item.php" style="color: white;">Cancle</a></button>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
        </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>

<script src="http://parsleyjs.org/dist/parsley.js"></script>
<script>
$("#patientData").parsley();
</script>
<?php 
    include "include/footer.php";
    include "include/script.php";
?>