<?php
include_once 'db.php';

if (isset($_POST['ni'])) {
    $Component_Category = $_POST['Component_Category'];
    $Component_Name = $_POST['Component_Name'];
    $Component_Discription = $_POST['Component_Discription'];
    $Cost = $_POST['Cost'];
 
  $sql = "INSERT INTO add_item_form(Component_Category,Component_Name,Component_Discription,Cost)
	 VALUES ('$Component_Category','$Component_Name','$Component_Discription','$Cost')";
    if (mysqli_query($con, $sql)) {

        echo "<script>alert('New record created successfully !')
        window.location.href = 'Add_lab_item.php';
      </script>";
    
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>

<?php

if (isset($_POST['Add'])) {

    header("location:Add_lab_item_form.php");

}

?>
