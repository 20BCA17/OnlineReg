
<?php
include "auth.php";
include "include/header.php";
?>

<style>

.custom-file-upload{
  background: #f7f7f7;
  padding: 8px;
  border: 1px solid #e3e3e3;
  border-radius: 5px;
  border: 1px solid #ccc;
  display: inline-block;
  padding: 6px 12px;
  cursor: pointer;
}
.dark{
    background-color:gray;
    color:white;

}
.icon{
  text-align: center;

}
.od{
    
    border-radius: 50px;
   background-color: #06d69f;
   font-size: 12px;
   color: white;
   text-align: center;
 padding: 10px ;
   
}



</style>

<div id="page-wrapper">
        <div id="page-inner">

            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                            Dashboard <small>Summary of your App</small>
                    </h1>
					<ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Library</a></li>
                        <li class="active">Data</li>
                    </ol>
                </div>
            </div>

            <div class="row">
                    <div class="col-lg-12">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Laboratory Management
                            </div>
                            <div class="panel-body">
                                <div class="form-row">
                                    <div class="col-lg-12">
                                        <form action="patient_insert.php" role="form" method="POST" enctype="multipart/form-data">
                                      

                                            <div class="form-group  col-md-2 ">
                                                <select name="" id="" class="form-control">
                                                    <option value="">All Patient</option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                    <option value=""></option>
                                                </select>
                                            </div>

                                            <div class="form-group  ">

                                            <div>
                                            <a href="export.php"><button type="button" class="btn btn-primary" >Export</button> </a>
                                            <input type="button" onclick="window.print()" value="print" class="btn btn-danger ">
                                            <button type="submit" name="add" class="btn btn-primary " style="float: right;">Add New
                                                    Patient</button>
                                                    </div>
                                                <!-- <button  class="btn btn-primary " id="hide"
                                                    style="float: right;" >Add
                                                    New
                                                    Patient </button> -->
                                            </div><br><br><br>
                                            <!-- table in data store -->
                                            <?php require "db.php";?>
                                           <?php
$data = mysqli_query($con, "SELECT * FROM idx_insert");
?>          
                                            <div class="dt">
                                            <div class="table-responsive"> 
                                            <table class="table table-striped table-hover  " id="dataTables-example">
                                                <thead>
                                                    <tr class="dark">
                                                        <th>Image</th>
                                                        <th>Name</th>
                                                        <th>Patient_Code</th>
                                                        <th>Age</th>
                                                        <th>Gender</th>
                                                        <th>Contact</th>
                                                        <th class="icon">Action</th>

                                                    </tr>
                                                </thead>
                                                <?php foreach ($data as $value) {?>
                                                <tr>
                                                <td><img width="100px" height="100px" src="upload/<?php echo $value['UploadDocument']; ?>"></td>
                                                <td><?php echo $value['Mr'] . "  " . $value['fname'] . "  " . $value['lname']; ?></td>
                                              <td><span class="od"><?php echo "OPD NO :".$value['id']; ?></span></td>  
                                                    <td><?php echo $value['fname']; ?></td>
                                                    <td><?php echo $value['gender']; ?></td>
                                                    <td><?php echo $value['Phone']; ?></td>
                                                    <td class="icon">
                                                  <a href="patient_edit.php?id=<?php echo $value['id']; ?>"><font color='Blue ' size='4px' ><i class="fas fa-edit" aria-hidden="true"></i></font></a>
                                                  &nbsp;
                                                  <a onclick="return confirm('Are you sure?')" href="patient_insert.php?id=<?php echo $value['id']; ?>"><font color='red ' size='4px'><i class="fa fa-trash "  ></i><span class="tooltiptext"></span></font></a>
                                               &nbsp;

                                                  <a href="ed.php?id=<?php echo $value['id']; ?>"><font color='black' size='4px'><i class="fa fa-eye" aria-hidden="true"></i></font></a></td>

                                                </tr>
                                             
                                                <?php }?>
                                          </table>
                                       
                     
                                            </div>
                                            </div>
                                    </div>

                            </div>
                                            </div>
                        </div>
                    </div>
        </div>
</div>

<?php
include "include/footer.php";
include "include/script.php";
?>

