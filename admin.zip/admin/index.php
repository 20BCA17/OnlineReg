<?php
include "include/header.php";
?>


<div id="page-wrapper">
        <div id="page-inner">

            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-header">
                            Dashboard <small>Summary of your App</small>
                    </h1>
					<ol class="breadcrumb">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Library</a></li>
                        <li class="active">Data</li>
                    </ol>
                </div>
            </div>

        </div>
</div>

<?php
include "include/footer.php";
include "include/script.php";
?>