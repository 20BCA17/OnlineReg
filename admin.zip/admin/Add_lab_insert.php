<?php
include_once 'db.php';

if (isset($_POST['save'])) {
    $Lab_Name = $_POST['Lab_Name'];
    $Registration = $_POST['Registration'];
    $Contact = $_POST['Contact'];
    // $UploadDocument = $_POST['UploadDocument'];
    $Mobile_No = $_POST['Mobile_No'];
    $Email_Add1 = $_POST['Email_Add1'];
    $Email_Add2 = $_POST['Email_Add2'];
    $Address_Line1 = $_POST['Address_Line1'];
    $Address_Line2 = $_POST['Address_Line2'];
    $Country = $_POST['Country'];
    $State = $_POST['State'];
    $City = $_POST['City'];
    $Pin = $_POST['Pin'];
    $Notes = $_POST['Notes'];
    $Active = $_POST['Active'];
  

    
	// $name = $_FILES['UploadDocument']['name'];
	// list($txt, $ext) = explode(".", $name);
	// $image_name = time().".".$ext;
	// $tmp = $_FILES['UploadDocument']['tmp_name'];

	// move_uploaded_file($tmp, 'upload/'.$image_name);


    $sql = "INSERT INTO Add_lab_insert (Lab_Name,Registration,Contact,Mobile_No,Email_Add1,Email_Add2,Address_Line1,Address_Line2,Country,State,City,Pin,Notes,Active)
	 VALUES ('$Lab_Name','$Registration','$Contact','$Mobile_No','$Email_Add1','$Email_Add2','$Address_Line1','$Address_Line2','$Country','$State','$City','$Pin','$Notes','$Active')";
    if (mysqli_query($con, $sql)) {

        echo "<script>alert('New record created successfully !')
        window.location.href = 'Addlab.php';
      </script>";
    
    } else {
        echo "Error: " . $sql . "
" . mysqli_error($con);
    }
    mysqli_close($con);
}

?>



<?php
include_once 'db.php';
$delete = "DELETE FROM Add_lab_insert WHERE id='" . $_GET["id"] . "'";
if (mysqli_query($con, $delete)) {
    header("location:Addlab.php");
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($con);
?>

<?php
include_once 'db.php';
if (isset($_POST['sub'])) {

    header("location:Add_lab_form.php");

}

?>
<?php
include_once 'db.php';
if (isset($_POST['cancle'])) {

    header("location:Addlab.php");

}

?>