-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2022 at 07:39 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_item_form`
--

CREATE TABLE `add_item_form` (
  `Id` int(50) NOT NULL,
  `Component_Category` varchar(100) NOT NULL,
  `Component_Name` varchar(100) NOT NULL,
  `Component_Discription` varchar(200) NOT NULL,
  `Cost` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `add_lab_insert`
--

CREATE TABLE `add_lab_insert` (
  `id` int(100) NOT NULL,
  `Lab_Name` varchar(50) NOT NULL,
  `Registration` varchar(50) NOT NULL,
  `Contact` varchar(50) NOT NULL,
  `Mobile_No` varchar(15) NOT NULL,
  `Email_Add1` varchar(20) NOT NULL,
  `Email_Add2` varchar(20) NOT NULL,
  `Address_Line1` varchar(255) NOT NULL,
  `Address_Line2` varchar(255) NOT NULL,
  `Country` varchar(20) NOT NULL,
  `State` varchar(20) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Pin` varchar(20) NOT NULL,
  `Notes` varchar(255) NOT NULL,
  `Active` varchar(10) NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `updated_at` timestamp(6) NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `idx_insert`
--

CREATE TABLE `idx_insert` (
  `id` int(20) NOT NULL,
  `Today_Date` varchar(20) NOT NULL,
  `Doctor_Name` varchar(50) NOT NULL,
  `Patient_Code` varchar(50) NOT NULL,
  `UploadDocument` varchar(255) NOT NULL,
  `Mr` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `dob_year` varchar(50) NOT NULL,
  `dob_month` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `flat` varchar(50) NOT NULL,
  `road` varchar(50) NOT NULL,
  `place` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `pin` varchar(50) NOT NULL,
  `Createda_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `Updateda_at` timestamp(6) NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `lab_detail_insert`
--

CREATE TABLE `lab_detail_insert` (
  `id` int(50) NOT NULL,
  `Start_Date` varchar(20) NOT NULL,
  `Select_Lab` varchar(50) NOT NULL,
  `Doctor_Name` varchar(50) NOT NULL,
  `End_Date` varchar(20) NOT NULL,
  `exampleRadios` varchar(10) NOT NULL,
  `Theeth_No` varchar(10) NOT NULL,
  `Sent` varchar(50) NOT NULL,
  `Select_Stage` varchar(50) NOT NULL,
  `Primary_Teeth` varchar(10) NOT NULL,
  `Select_All_Teeth` varchar(10) NOT NULL,
  `Select_Components_items` varchar(50) NOT NULL,
  `Select_Tooth` varchar(20) NOT NULL,
  `Price` varchar(20) NOT NULL,
  `Total_Cost` varchar(20) NOT NULL,
  `Order_Placed` varchar(50) NOT NULL,
  `Instruction` varchar(255) NOT NULL,
  `Created_ad` timestamp(6) NULL DEFAULT current_timestamp(6),
  `Updated_at` timestamp(6) NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(20) NOT NULL,
  `created_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `updated_at` timestamp(6) NULL DEFAULT current_timestamp(6),
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `number` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `created_at`, `updated_at`, `firstName`, `lastName`, `gender`, `email`, `password`, `number`) VALUES
(1, '2022-08-01 17:25:18.247826', '2022-08-01 17:25:18.247826', 'admin', 'user', 'm', 'admin@gmail.com', '25d55ad283aa400af464', '7359817263'),
(2, '2022-08-01 17:36:30.502360', '2022-08-01 17:36:30.502360', 'CPM', 'Ltd', 'm', 'vrutikapatel47111@gmail.com', '25d55ad283aa400af464', '1234567897'),
(3, '2022-08-01 17:38:03.784370', '2022-08-01 17:38:03.784370', 'CPM', 'Ltd', '', 'vrutikapatel47111@gmail.com', '25d55ad283aa400af464', '1356878788');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_item_form`
--
ALTER TABLE `add_item_form`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `add_lab_insert`
--
ALTER TABLE `add_lab_insert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `idx_insert`
--
ALTER TABLE `idx_insert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lab_detail_insert`
--
ALTER TABLE `lab_detail_insert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_item_form`
--
ALTER TABLE `add_item_form`
  MODIFY `Id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `add_lab_insert`
--
ALTER TABLE `add_lab_insert`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `idx_insert`
--
ALTER TABLE `idx_insert`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lab_detail_insert`
--
ALTER TABLE `lab_detail_insert`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
